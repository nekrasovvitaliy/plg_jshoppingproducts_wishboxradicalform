<?php
// phpcs:disable PSR1.Files.SideEffects
\defined('_JEXEC') or die;
// phpcs:enable PSR1.Files.SideEffects
?>
<a
	href="javascript:void(0);"
	rel="wishboxradicalform"
	onclick="jQuery('#wishboxradicalform').modal('show');"
>
	Задать вопрос
</a>